/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraybasedqueue;

import java.util.Collection;
import java.util.Iterator;
import java.util.Queue;

/**
 *
 * @author hp


/**
 * Author: bbrighttaer
 * @param <E> Generic type
 */
public class ArrayBasedQueue<E> implements Queue<E> {
    private int size;
    private int head_index;
    private final E[] queue;

    public ArrayBasedQueue(int queue_size) {
        this.size = 0;
        this.head_index = 0;
        this.queue = (E[]) new Object[queue_size];
    }

    //@Override
    public void enqueue(E element) {
        int insertion_index = (head_index + size) % queue.length;
        this.queue[insertion_index] = element;
        size++;
    }

    //@Override
    public E dequeue() throws Exception {
        checkQueue();
        E out = queue[head_index];
        head_index = (head_index + 1) % queue.length;
        size--;
        return out;
    }

    private void checkQueue() throws Exception {
        if (isEmpty())
            throw new Exception("The queue is empty");
    }

    //@Override
    public E first() throws Exception {
        checkQueue();
        return queue[head_index];
    }

    //@Override
    public int getSize() {
        return size;
    }

    //@Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public String toString() {
        StringBuilder bldr = new StringBuilder();
        if (!isEmpty()) {
            for (int i = 0; i < queue.length; i++) {
                bldr.append(queue[i]);
                if (i + 1 != queue.length)
                    bldr.append(", ");
            }
        }
        return String.format("ArrayBasedQueue[%s]", bldr);
    }

    @Override
    public boolean add(E e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean offer(E e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public E remove() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public E poll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public E element() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public E peek() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int size() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean contains(Object o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Iterator<E> iterator() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object[] toArray() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public <T> T[] toArray(T[] a) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean remove(Object o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean addAll(Collection<? extends E> c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void clear() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

