/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraybasedqueue;

import java.util.Arrays;

/**
 *
 * @author hp
 */
public class Main {
    public static void main(String[] args) throws Exception {
        int queue_size = 10;
        ArrayBasedQueue<Integer> queue = new ArrayBasedQueue<>(queue_size);
        print(queue);

        // populate queue with random integers between 0 and 10 (inclusive)
        int[] added_elements = new int[12];
        for(int i = 0; i < 12; i++){
            int element = (int) (Math.random() * 11);
            added_elements[i] = element;
            queue.enqueue(element); 
            
        }
        
        print(queue);
        
        // repetitive removal
        
        int[] removed = new int[queue.getSize()-2];
        for(int i = 0; i < queue_size; i++){
            int element = queue.dequeue();
            removed[i] = element;
            
            
        }
        print("repititive removal "+Arrays.toString(removed));
         
        /**
         * Print the elements of the queue in the right order
         * i.e. the head first, and the tail last.
         * In your codes to demonstrate your solution, ensure that
         * the head of the queue is in the middle of the array backing the queue.
         */
        //Put your codes here
        int[] elements_added = new int[12];
        for(int  k=2; k<12; k++ ){
            elements_added[0] = added_elements[10];
             elements_added[1] = added_elements[11];
              elements_added[k] = added_elements[k];
            
        }
        
        print("Order of addition "+Arrays.toString(elements_added));
        print("HEAD: "+queue.first());
        print("TAIL: "+removed[queue_size-1]);

    }

    public static void print(Object o){
        System.out.println(o.toString());
    }
}
